const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  isElectron: true,
  scanDefaultLibraries: selection => ipcRenderer.invoke('scan-default-libraries', selection),
  readFiles: paths => ipcRenderer.invoke('read-files', paths),
  readFile: filePath => ipcRenderer.invoke('read-file', filePath),
  readAppAsset: relativePath => ipcRenderer.invoke('read-app-asset', relativePath),
  openFolder: () => ipcRenderer.invoke('open-folder'),
  openImageFolder: () => ipcRenderer.invoke('open-image-folder'),
  openFiles: () => ipcRenderer.invoke('open-files'),
  rescanFolder: folderPath => ipcRenderer.invoke('rescan-folder', folderPath),
  saveFile: data => ipcRenderer.invoke('save-file', data),
  fetchPDF: url => ipcRenderer.invoke('fetch-pdf', url),
  saveDownloadedPDF: data => ipcRenderer.invoke('save-downloaded-pdf', data),
  saveProject: state => ipcRenderer.invoke('save-project', state),
  loadProject: () => ipcRenderer.invoke('load-project'),
  showInFolder: filePath => ipcRenderer.invoke('show-in-folder', filePath),
  onMenuOpenFolder: () => {},
  onMenuImportFiles: () => {},
  onMenuExport: () => {},
  onMenuSave: () => {},
  onMenuUndo: () => {},
  onMenuRedo: () => {}
});
