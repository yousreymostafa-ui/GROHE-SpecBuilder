PDF KIT PRO v12.11.1 — WINDOWS DESKTOP

Fixed folders:
  Data sheets: G:\My Drive\Data Sheets
  Product images: G:\My Drive\Images

How to start:
  1. Install Node.js LTS once if it is not already installed.
  2. Double-click Install_and_Run.bat.
  3. Tick PDF data sheets, product images, or both.
  4. Click Scan now. Your choice is remembered.

SKU entry:
  - Standard GROHE codes such as 2511700A, 25 117 00A, and 23296DC1 are products.
  - A code followed by description text is also a product and matches using its code.
  - Text such as Option 1 or Bathroom 2 is treated as a section page.
  - Prefix a line with # to force a section, for example: # Option 1.
  - Every product row has Make break for quick manual correction.

Scan now refreshes only the source types you ticked.
PDF filenames are indexed immediately, so linked/missing status refreshes without waiting for every PDF to open.
PDF contents and page counts load only for products used in the current document.
SKU matching also finds codes inside longer filenames, including GROHE_2511700A_specification.pdf.
The Arrange sequence panel can be filtered by All, Linked, Missing, or Titles / breaks.
The Chrome or desktop window title always remains PDF KIT PRO, regardless of the project name.
The Project & document name field controls the cover and saved project.
Project details appear on the line below the project name.
The default PDF name is created automatically as:
  Project name Technical Data Sheet.pdf
You can edit the final filename before export.

Project memory:
  - Projects save automatically inside the app.
  - The Save project button beside the project fields saves the current document explicitly.
  - Click Project history to search, reopen, or duplicate any previous project.
  - Duplicate creates an independent copy with all sequence, cover, and export settings.
  - Opening an old project and changing its name starts a separate history entry instead of overwriting the original.
  - Use New to start a clean project while preserving all earlier projects.
  - JSON download/import remains available only as an optional backup.

Paste safety:
  - Clipboard text is accepted only inside the visible SKU input box.
  - Unsaved SKU input is cleared when you open or start another project.
  - Delayed saves from a previous project cannot update the newly opened project.

Cover and missing items:
  - Contact details are enabled by default from the right-side Cover options.
  - Choose from six built-in A4 GROHE cover designs.
  - Every cover uses the same approved, clear GROHE logo placement.
  - The selected cover is remembered with the saved project and used in the exported PDF.
  - Consecutive breaks are styled as a calm-blue Area heading followed by a lighter Category heading.
  - Break titles remain clearly visible while hovering, focusing, and editing.
  - Every missing SKU keeps its Google search icon and remembers the searched status.
  - Missing-filter bulk search checks GROHE MENA and GROHE SUK for every unique missing SKU.
  - Verified direct PDFs and targeted manual search links are clearly separated.
  - Open any verified PDF individually or use Open all verified PDFs.
  - PDF KIT PRO only locates and opens links; it never downloads or saves them automatically.
  - The Data Sheets folder is checked automatically every 5 seconds.

If the Google Drive letter or folder names change, edit DEFAULT_PDF_PATH and DEFAULT_IMAGE_PATH near the top of main.js.

v12.11.1 reliability update:
  - Sequence search now sits beside Save project, and the redundant Arrange sequence header strip and Add item button are removed.
  - Startup finishes restoring the last project before item entry is enabled, so older generated items cannot replace newly added items.
  - Project autosaves are serialized and the Windows autosave file is replaced atomically, preventing an older save from winning a timing race.
  - Export waits for folder scans, loads and locks every linked source PDF, then merges from that stable snapshot.
  - The complete page count is verified before and after compression; an incomplete or cover-only PDF is blocked instead of being saved.

v12.11 update:
  - All six embedded covers now use the same validated image-byte path during export.
  - Cover selection cannot silently skip or corrupt the merged project pages.
  - The export checks the complete expected page count before saving.
  - Bulk missing search now performs official-source lookups instead of treating constructed URLs as found PDFs.
  - Verified PDFs are separated from GROHE MENA and GROHE SUK fallback searches.

v12.10 update:
  - Restores PDF export after the sequence-footer cleanup removed an internal compatibility hook.
  - Keeps the duplicate Review control hidden while preserving export engine compatibility.
  - Removes the Duplicate status badge from sequence rows, leaving one Linked badge.
  - Rebuilds and validates PDF bytes before saving or downloading.

v12.9 update:
  - The supplied GROHE logo PNG is embedded unchanged inside the HTML.
  - The same exact logo appears on all six cover thumbnails, the main cover preview, and exported PDFs.
  - Logo opacity is fixed at 100% with no blur, filter, transform, rounded corners, or shadow.
  - Every cover uses identical top-right size and placement.

v12.8 update:
  - Product rows display only the GROHE SKU/code.
  - The Linked badge sits immediately after the code; the Ready/page badge is removed.
  - Clear all sequence items is directly below Add to sequence.
  - The duplicate sequence-footer Review control is removed.
  - The Missing filter counter uses a distinct warning color.
  - The main cover preview shows the complete A4 cover without cropping.
  - Cover, contact, TOC, page-number, and divider options are grouped under collapsed Output settings.
  - Compress final PDF remains visible; its quality setting appears only when compression is enabled.
  - Number the cover, Number the TOC, number format, and number position controls are removed.

v12.7 update:
  - SKU lists are inserted immediately without a paste-review window.
  - GROHE MENA and GROHE SUK are the primary missing-PDF search sources.
  - All six cover images are embedded inside the HTML; no cover folder is required.
  - Cover previews are larger and easier to compare.

v12.6 cleanup:
  - Draft autosave and manual project saving are now clearly separated.
  - Save as new project is available from the Save project menu.
  - File checks and page preview use one Review workflow with two tabs.
  - Irrelevant export controls stay hidden until their parent option is enabled.
  - Duplicate SKUs are preserved and never removed automatically.
  - Area sections can be collapsed, and every break can be set to Auto, Area, Category, or Break.
  - Duplicate SKUs are never removed automatically.
