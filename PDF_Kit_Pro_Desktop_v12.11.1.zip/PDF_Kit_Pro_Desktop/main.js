const { app, BrowserWindow, dialog, ipcMain, shell } = require('electron');
const fs = require('fs');
const path = require('path');
const { pathToFileURL } = require('url');

const DEFAULT_PDF_PATH = String.raw`G:\My Drive\Data Sheets`;
const DEFAULT_IMAGE_PATH = String.raw`G:\My Drive\Images`;
const PDF_EXTENSIONS = new Set(['.pdf']);
const IMAGE_EXTENSIONS = new Set(['.png', '.jpg', '.jpeg', '.webp', '.gif', '.bmp']);

function walk(root, extensions) {
  if (!root || !fs.existsSync(root)) return [];
  const results = [];
  const pending = [root];
  while (pending.length) {
    const current = pending.pop();
    let entries = [];
    try { entries = fs.readdirSync(current, { withFileTypes: true }); } catch { continue; }
    for (const entry of entries) {
      const full = path.join(current, entry.name);
      if (entry.isDirectory()) pending.push(full);
      else if (entry.isFile() && extensions.has(path.extname(entry.name).toLowerCase())) results.push(full);
    }
  }
  return results.sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
}

function scanLibraries(selection = {}) {
  const loadPdfs = selection.pdfs !== false;
  const loadImages = selection.images !== false;
  const pdfFiles = loadPdfs ? walk(DEFAULT_PDF_PATH, PDF_EXTENSIONS) : [];
  const imageFiles = loadImages ? walk(DEFAULT_IMAGE_PATH, IMAGE_EXTENSIONS) : [];
  return {
    pdfPath: DEFAULT_PDF_PATH,
    imagePath: DEFAULT_IMAGE_PATH,
    pdfFiles,
    pdfIndex: pdfFiles.map(filePath => {
      let stat = null;
      try { stat = fs.statSync(filePath); } catch {}
      return {
        name: path.basename(filePath),
        path: filePath,
        size: stat ? stat.size : 0,
        modified: stat ? stat.mtimeMs : 0
      };
    }),
    images: imageFiles.map(filePath => ({ name: path.basename(filePath), path: filePath, url: pathToFileURL(filePath).href })),
    pdfPathFound: fs.existsSync(DEFAULT_PDF_PATH),
    imagePathFound: fs.existsSync(DEFAULT_IMAGE_PATH)
  };
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1500,
    height: 930,
    minWidth: 1080,
    minHeight: 700,
    backgroundColor: '#f1f5f9',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false }
  });
  win.loadFile(path.join(__dirname, 'pdf_kit_pro.html'));
}

ipcMain.handle('scan-default-libraries', (_event, selection) => scanLibraries(selection || {}));
ipcMain.handle('read-files', (_event, paths) => (paths || []).map(filePath => {
  const data = fs.readFileSync(filePath);
  return { name: path.basename(filePath), path: filePath, buffer: data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength) };
}));
ipcMain.handle('read-file', (_event, filePath) => {
  const data = fs.readFileSync(filePath);
  return {
    name: path.basename(filePath),
    path: filePath,
    buffer: data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength)
  };
});
ipcMain.handle('read-app-asset', (_event, relativePath) => {
  const normalized = String(relativePath || '').replace(/\\/g, '/');
  if (!/^covers\/cover_0[1-6]\.jpg$/.test(normalized)) throw new Error('Unknown app asset');
  const data = fs.readFileSync(path.join(__dirname, ...normalized.split('/')));
  return { buffer: data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength) };
});
ipcMain.handle('open-folder', async () => {
  const result = await dialog.showOpenDialog({ properties: ['openDirectory'] });
  if (result.canceled || !result.filePaths[0]) return null;
  const folderPath = result.filePaths[0];
  return { folderPath, files: walk(folderPath, PDF_EXTENSIONS) };
});
ipcMain.handle('open-image-folder', async () => {
  const result = await dialog.showOpenDialog({ properties: ['openDirectory'] });
  if (result.canceled || !result.filePaths[0]) return null;
  const folderPath = result.filePaths[0];
  const files = walk(folderPath, IMAGE_EXTENSIONS);
  return { folderPath, images: files.map(filePath => ({ name: path.basename(filePath), url: pathToFileURL(filePath).href })) };
});
ipcMain.handle('open-files', async () => {
  const result = await dialog.showOpenDialog({ properties: ['openFile', 'multiSelections'], filters: [{ name: 'PDF files', extensions: ['pdf'] }] });
  return result.canceled ? null : result.filePaths;
});
ipcMain.handle('rescan-folder', (_event, folderPath) => ({ folderPath, files: walk(folderPath, PDF_EXTENSIONS) }));
ipcMain.handle('save-file', async (_event, { defaultName, pdfBytes }) => {
  const result = await dialog.showSaveDialog({ defaultPath: defaultName, filters: [{ name: 'PDF', extensions: ['pdf'] }] });
  if (result.canceled || !result.filePath) return null;
  fs.writeFileSync(result.filePath, Buffer.from(pdfBytes));
  return result.filePath;
});
ipcMain.handle('fetch-pdf', async (_event, remoteUrl) => {
  const url = new URL(String(remoteUrl || ''));
  if (url.protocol !== 'https:') throw new Error('Only secure PDF links are supported');
  const response = await fetch(url, {
    redirect: 'follow',
    headers: { 'User-Agent': 'Mozilla/5.0 PDF KIT PRO', Accept: 'application/pdf,*/*;q=0.8' }
  });
  if (!response.ok) throw new Error(`PDF server returned ${response.status}`);
  const bytes = new Uint8Array(await response.arrayBuffer());
  if (bytes.length > 35 * 1024 * 1024) throw new Error('PDF is larger than 35 MB');
  if (Buffer.from(bytes.slice(0, 5)).toString('ascii') !== '%PDF-') throw new Error('The selected result is not a valid PDF');
  return { buffer: bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) };
});
ipcMain.handle('save-downloaded-pdf', (_event, { name, pdfBytes }) => {
  fs.mkdirSync(DEFAULT_PDF_PATH, { recursive: true });
  const safeName = path.basename(String(name || 'GROHE.pdf')).replace(/[^A-Za-z0-9._-]/g, '_');
  const target = path.join(DEFAULT_PDF_PATH, safeName.toLowerCase().endsWith('.pdf') ? safeName : `${safeName}.pdf`);
  fs.writeFileSync(target, Buffer.from(pdfBytes));
  return target;
});
ipcMain.handle('save-project', (_event, state) => {
  const target = path.join(app.getPath('userData'), 'autosave.json');
  const temporary = `${target}.writing`;
  fs.writeFileSync(temporary, JSON.stringify(state || {}));
  fs.renameSync(temporary, target);
  return true;
});
ipcMain.handle('load-project', () => {
  const file = path.join(app.getPath('userData'), 'autosave.json');
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return null; }
});
ipcMain.handle('show-in-folder', (_event, filePath) => shell.showItemInFolder(filePath));

app.whenReady().then(createWindow);
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
